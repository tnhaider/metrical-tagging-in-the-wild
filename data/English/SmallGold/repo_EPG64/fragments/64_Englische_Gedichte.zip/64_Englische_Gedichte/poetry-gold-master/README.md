English Poetry Gold Corpus

Diachronically balanced, hand selected.

Still missing Schema file.


